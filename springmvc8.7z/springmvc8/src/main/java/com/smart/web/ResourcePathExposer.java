package com.smart.web;

import org.springframework.web.context.ServletContextAware;

import javax.servlet.ServletContext;

public class ResourcePathExposer implements ServletContextAware {

    private ServletContext servletContext;
    private String resourceRoot;

    public void init(){
        //在实际应用中，可以在外部属性文件或数据库中保存应用的发布版本号，在此处获取之，此处仅仅提供了一个模拟值
        String version = "1.2.1";
        //资源逻辑路径带上应用的发布版本号
        resourceRoot = "/resources-" + version;
        //将资源逻辑路径暴露到ServletContext的属性列表中
        getServletContext().setAttribute("resourceRoot", getServletContext().getContextPath() + resourceRoot);
    }
    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    public String getResourceRoot() {
        return resourceRoot;
    }

    public ServletContext getServletContext() {
        return servletContext;
    }
}
