package com.smart.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/user")
public class UserController {
    @RequestMapping("/throwException")
    public String throwException(){
        if(2 > 1){
            throw new RuntimeException("ddd");
        }
        return "success";
    }

    @ExceptionHandler
    public String handleException(RuntimeException re, HttpServletRequest request){
        return "forwoad:/error.jsp";
    }
}
